package com.example.konversi

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val button: Button = findViewById(R.id.konversi)
        val text: EditText = findViewById(R.id.input)
        val opt: RadioGroup = findViewById(R.id.option)
        val view: TextView = findViewById(R.id.hasil)

        button.setOnClickListener {
            val s : String = text.text.toString()
            val number = s.toDoubleOrNull()
            val x = when(opt.checkedRadioButtonId)
            {
                R.id.bt1 -> 14.400
                R.id.bt2 -> 0.63
                R.id.bt3 -> 113.61
                R.id.bt4 -> 3.392
                else -> 0.0
            }
            val hasil = number?.times(x)
            view.setText(R.string.hasil)
            Toast.makeText(this, " Hasil Konversi $hasil", Toast.LENGTH_SHORT ).show()
        }

        }


    }


