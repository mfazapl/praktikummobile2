package com.example.konversi

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val value : EditText = findViewById(R.id.textfield)
        val myButton : Button = findViewById(R.id.konversi)
        .setOnClickListener(){
            val
        }
        val percentag = when (R.id.option) {
            R.id.bt1 -> 14.500
            R.id.bt2 -> 0.63
            R.id.bt3 -> 114.64
            R.id.bt4 -> 3340.31
            else -> 0.0
        }
        fun calculated() {

        }

    }
}
